# Simple Calculator
A Java Swing calculator application designed to perform common mathematical operations.
